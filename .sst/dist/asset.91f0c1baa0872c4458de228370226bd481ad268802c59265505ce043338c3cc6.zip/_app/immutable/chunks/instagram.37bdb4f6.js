const s=""+new URL("../assets/facebook.bc92bc1e.svg",import.meta.url).href,e=""+new URL("../assets/instagram.139e2d52.svg",import.meta.url).href;export{s as f,e as i};
