const e=""+new URL("../assets/2.ffcf0004.jpg",import.meta.url).href;export{e as i};
