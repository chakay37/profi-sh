const s=""+new URL("../assets/facebook.25feb1f1.svg",import.meta.url).href,e=""+new URL("../assets/instagram.483820de.svg",import.meta.url).href;export{s as f,e as i};
